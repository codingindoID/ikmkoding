<!-- /.content-wrapper -->
<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>IKM</b> 1.0
  </div>
  <strong>Copyright &copy; 2020 <a href="https://pengenngoding.com">IKM-DPMPTSP</a>.</strong> All rights
  reserved.
</footer>
