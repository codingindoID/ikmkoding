 <section id="contact" class="contact">
  <div class="container">

   <div class="section-title" data-aos="fade-up">
    <h2>MPP Kabupaten Jepara</h2>
    <p>Kirim Pertanyaan</p>
  </div>

  <div class="row" style="margin-top: -60px;">
    <div class="col-lg-4" data-aos="fade-right" data-aos-delay="100" >
      <div class="info" >
        <div class="address" style="margin-top: 30px;">
          <i class="icofont-google-map"></i>
          <h4>Alamat:</h4>
          <p>Jl. Kartini No. 1 Jepara</p>
        </div>
      </div>
    </div>
    <div class="col-lg-4" data-aos="fade-right" data-aos-delay="100">
      <div class="info">
        <div class="email">
          <i class="icofont-envelope"></i>
          <h4>Email:</h4>
          <p>dpmptsp@gmail.com</p>
        </div>
      </div>
    </div>
    <div class="col-lg-4" data-aos="fade-right" data-aos-delay="100">
      <div class="info">
        <div class="phone">
          <i class="icofont-phone"></i>
          <h4>telp:</h4>
          <p>+1 5589 55488 55</p>
        </div>

      </div>

    </div>

  </div>

</div>
</section>